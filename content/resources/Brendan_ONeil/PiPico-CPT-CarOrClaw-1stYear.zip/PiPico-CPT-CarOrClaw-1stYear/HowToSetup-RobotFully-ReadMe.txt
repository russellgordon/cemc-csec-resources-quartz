1. hold down boot button and plug in Pico-W
2. copy flash_nuke.uf2 onto Pico-W --> drag & drop
3. open Thonny and pick Run-->Configure Interpreter
4. set Interpreter to "Micro Python" and Port to "try to detect..."
5. click bottom right "Install Micro Python" blue text
6. set target to E: drive; family to RP2; and variant -->"raspberry pi -  pico-W"
7. click Install button
8. close & OK back to Thonny startup screen...
9. open on C: drive my "...Zumo..." robot code and copy to Raspberrry Pi
10.tools-->manage packages--> type in ssd1306  then "search" button
11.click on SSD1306 and install button below
Notice a Lib folder now on your raspberry Pico W --> inside this SSD1306 file
-run this to test
-save your robot code as main.py -->then runs on bootup!!! fully done!!!