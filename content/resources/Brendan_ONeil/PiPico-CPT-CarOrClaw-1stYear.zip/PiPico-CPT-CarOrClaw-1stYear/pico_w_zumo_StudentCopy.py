import network
import socket
from time import sleep
import machine

from machine import Pin,I2C
from ssd1306 import SSD1306_I2C

#SJA setting or HOME SETTINGS!!!
ssid='CompEngDpcdsb'
password='CompEng2023!'

i2c = I2C(0,sda=Pin(0),scl=Pin(1),freq=400000)
dsp= SSD1306_I2C(128,64,i2c)

# Define pins to pin motors!


#Your pins defined above here!!!

#Student actions below
#this action is for forward
def move_forward():
    print("Forward signals???")

#this action is for backward
def move_backward():
    print("Backward signals???")

#this action is for STOP!!!
def move_stop():
    print("MUST STOP ROBOT FIRST!!!SIGNALS")

#Stop the robot as soon as possible
move_stop()

def connect():
    #Connnect to WLAN
    wlan=network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(ssid,password)
    while wlan.isconnected()==False:
        print("Waiting for connection...")
        sleep(1)
    ip=wlan.ifconfig()[0]
    print(f'Connected on {ip}')
    return ip

def open_socket(ip):
    #open a socket
    address=(ip,80)
    connection=socket.socket()
    connection.bind(address)

    dsp.text(str(ip),0,0) #IP:
    dsp.text('PORT: '+str(80),0,16)
    dsp.show()  #test

    connection.listen(1)
    return connection

#Student controls built within here!!!
def webpage():
    #Template HTML
    html=f"""
        <!DOCTYPE html>
        <html>
        <head>
        <title>Zumo Robot Control</title>
        </head>
        <center><b>
        <form action="./forward">
        <input type="submit" value="Forward" style="height:120px;width:120px" />
        </form>
        <table><tr>
        <td><form action="./stop">
        <input type="submit" value="Stop" style="height:120px;width:120px" />
        </form></td>
        </tr></table>
        <form action="./back">
        <input type="submit" value="Back" style="height:120px;width:120px" />
        </form>
        </body>
        </html>
        """
    return str(html)

def serve(connection):
    #Start web server
    while True:
        client=connection.accept()[0]
        request=client.recv(1024)
        request=str(request)
        try:
            request=request.split()[1]
        except IndexError:
            pass

	#Student actions below!!!
        if request=='/forward?':
            move_forward()
        elif request=='/stop?':
            move_stop()
        elif request=='/back?':
            move_backward()
        html=webpage()
        client.send(html)
        client.close()

try:
    ip=connect()
    connection=open_socket(ip)
    serve(connection)
except KeyboardInterrupt:
    machine.reset()
