import socket
#blueServerAddress=('192.168.0.107',2222)
ServerAddress=('192.168.1.42',2222)
bufferSize=1024
UDPClient=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
while True:
    cmd=input('What is your Color? ')
    cmdEncoded=cmd.encode('utf-8')
    UDPClient.sendto(cmdEncoded,ServerAddress) #test
    data,address=UDPClient.recvfrom(bufferSize)
    dataDecoded=data.decode('utf-8')
    print('Message from Server: ',dataDecoded)
    
    
