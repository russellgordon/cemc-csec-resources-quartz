class Member:
    def __init__(self, name, age):
        """Takes a name and age and creates a Member object.

                    Parameters:
                    name : string
                    age : int

                    Returns:
                    Member
                    """
        self.name = name
        self.age = age
        self.children = []

    def addChild(self, name, age):
        """Takes a name and age and adds a Member as a child.

                            Parameters:
                            name : string
                            age : int

                            Returns:
                            FamilyTree
                            """
        self.children.append(Member(name, age))
