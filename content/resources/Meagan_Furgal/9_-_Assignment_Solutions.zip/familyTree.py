from member import Member


class FamilyTree:
    def __init__(self, name, age):
        """Creates a FamilyTree object that has a root Member with name and age.

                    Parameters:
                    name : string
                    age : int

                    Returns:
                    FamilyTree
                    """
        self.root = Member(name, age)

    # Use a wrapper function
    def findMember(self, name):
        """Searches the family tree for a member with the provided name.

                    Parameters:
                    name : string

                    Returns:
                    Member or None
                    """
        return self.findMemberRecursive(self.root, name)

    def findMemberRecursive(self, cur_member, name):
        """Takes a Member and a name and searches the Member's
           children recursively for a Member with the provided name.

                    Parameters:
                    cur_member : Member
                    name : String

                    Returns:
                    Member or None
                    """
        # Base case: current member is the correct one
        if cur_member.name == name:
            return cur_member
        # Recursive case: call method on each child
        for child in cur_member.children:
            mem = self.findMemberRecursive(child, name)
            if mem:
                return mem

        # all members have been searched with no match
        return None

    def addMember(self, name, age, parent):
        """Takes a name, age and parent and adds a Member
           to the tree as a child of the provided parent.

                    Parameters:
                    name : string
                    age : int
                    parent : string

                    Returns:
                    None
                    """
        p = self.findMember(parent)
        if p:
            p.addChild(name, age)

    def youngestMember(self):
        """Searches the FamilyTree and prints the youngest member's name and age.

                    Parameters:
                    None

                    Returns:
                    None
                    """
        youngest = self.youngestMemberRecursive(self.root)
        print("Youngest member is:", youngest.name, "- age", youngest.age)

    def youngestMemberRecursive(self, cur_member):
        """Takes a Member and searches the Member's children recursively
           and returns the youngest member.

                    Parameters:
                    cur_member : Member

                    Returns:
                    Member
                    """
        cur_youngest = cur_member
        for child in cur_member.children:
            youngest = self.youngestMemberRecursive(child)
            if youngest.age < cur_youngest.age:
                cur_youngest = youngest

        return cur_youngest

    def printTree(self):
        """Prints the FamilyTree.

                    Parameters:
                    None

                    Returns:
                    None
                    """
        self.printTreeRecursive(self.root, 0)

    def printTreeRecursive(self, cur_member, level):
        """Takes a Member and its level in the family tree and
           prints the Member and its children recursively.

                    Parameters:
                    cur_member : Member
                    level : int

                    Returns:
                    None
                    """
        # indent 1 tab for each level in the tree
        indent = "\t" * level
        print(f"{indent}{cur_member.name}")
        for child in cur_member.children:
            self.printTreeRecursive(child, level + 1)
