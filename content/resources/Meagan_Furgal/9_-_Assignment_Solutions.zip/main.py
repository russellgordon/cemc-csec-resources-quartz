from familyTree import FamilyTree

MENU = """
**********MENU**********
1 - Display the family tree
2 - Find a member
3 - Add a member
4 - Find the youngest member
5 - Quit

Option: """


def main():
    """Takes user input to interact with a virtual family tree.

        Parameters:
            None

        Returns:
            None
        """
    command = 0
    # create family tree
    name = input("Enter family member's name:")
    age = int(input("Enter age of family member:"))
    tree = FamilyTree(name, age)

    while command != 5:
        command = int(input(MENU))  # assuming numeric input

        # display tree
        if command == 1:
            tree.printTree()

        # find a member
        elif command == 2:
            name = input("Enter family member's name:")
            member = tree.findMember(name)
            if member is None:
                print("No member with that name could be found")
            else:
                print("Member found! Name:", member.name, "Age:", member.age)

        # add a member
        elif command == 3:
            name = input("Enter family member's name:")
            age = int(input("Enter age of family member:"))
            parent = input("Enter family member's parent:")
            if tree.findMember(parent) is None:
                print("Unable to add member if parent is not in the family tree")
            else:
                tree.addMember(name, age, parent)

        # find youngest member
        elif command == 4:
            tree.youngestMember()


main()